﻿namespace Network_Statistics
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.Save_Metrics = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.richTextBox2 = new System.Windows.Forms.RichTextBox();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.compare_button = new System.Windows.Forms.Button();
            this.CommandLabel = new System.Windows.Forms.Label();
            this.CommandTxtBox = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(137, 44);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(147, 23);
            this.button1.TabIndex = 0;
            this.button1.Text = "Get Netstat";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 92);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(78, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Start Netstat -b";
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(137, 92);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.Size = new System.Drawing.Size(280, 287);
            this.richTextBox1.TabIndex = 2;
            this.richTextBox1.Text = "";
            // 
            // Save_Metrics
            // 
            this.Save_Metrics.Location = new System.Drawing.Point(302, 44);
            this.Save_Metrics.Name = "Save_Metrics";
            this.Save_Metrics.Size = new System.Drawing.Size(93, 23);
            this.Save_Metrics.TabIndex = 3;
            this.Save_Metrics.Text = "Save Metrics";
            this.Save_Metrics.UseVisualStyleBackColor = true;
            this.Save_Metrics.Click += new System.EventHandler(this.Save_Metrics_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(518, 44);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(136, 23);
            this.button2.TabIndex = 4;
            this.button2.Text = "Load Baseline";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // richTextBox2
            // 
            this.richTextBox2.Location = new System.Drawing.Point(462, 92);
            this.richTextBox2.Name = "richTextBox2";
            this.richTextBox2.Size = new System.Drawing.Size(280, 287);
            this.richTextBox2.TabIndex = 5;
            this.richTextBox2.Text = "";
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // compare_button
            // 
            this.compare_button.Location = new System.Drawing.Point(388, 405);
            this.compare_button.Name = "compare_button";
            this.compare_button.Size = new System.Drawing.Size(114, 23);
            this.compare_button.TabIndex = 6;
            this.compare_button.Text = "Compare";
            this.compare_button.UseVisualStyleBackColor = true;
            this.compare_button.Click += new System.EventHandler(this.compare_button_Click);
            // 
            // CommandLabel
            // 
            this.CommandLabel.AutoSize = true;
            this.CommandLabel.Location = new System.Drawing.Point(13, 223);
            this.CommandLabel.Name = "CommandLabel";
            this.CommandLabel.Size = new System.Drawing.Size(57, 13);
            this.CommandLabel.TabIndex = 7;
            this.CommandLabel.Text = "Command:";
            // 
            // CommandTxtBox
            // 
            this.CommandTxtBox.Location = new System.Drawing.Point(12, 254);
            this.CommandTxtBox.Name = "CommandTxtBox";
            this.CommandTxtBox.Size = new System.Drawing.Size(100, 20);
            this.CommandTxtBox.TabIndex = 8;
            this.CommandTxtBox.Text = "Netstat -b";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.CommandTxtBox);
            this.Controls.Add(this.CommandLabel);
            this.Controls.Add(this.compare_button);
            this.Controls.Add(this.richTextBox2);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.Save_Metrics);
            this.Controls.Add(this.richTextBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Name = "Form1";
            this.Text = "Netstat  compare";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Button Save_Metrics;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.RichTextBox richTextBox2;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
        private System.Windows.Forms.Button compare_button;
        private System.Windows.Forms.Label CommandLabel;
        private System.Windows.Forms.TextBox CommandTxtBox;
    }
}

