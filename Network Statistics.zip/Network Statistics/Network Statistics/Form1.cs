﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;
using System.IO;
using System.Threading;

namespace Network_Statistics
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            label1.Text = "Loading...please wait";           
            label1.Refresh();
            string command2Run = CommandTxtBox.Text;

            //This is the executable that will run
            Process cmd = new Process();
            cmd.StartInfo.FileName = "cmd.exe"; 
            cmd.StartInfo.RedirectStandardOutput = true; //to read
            cmd.StartInfo.RedirectStandardInput = true;
            cmd.StartInfo.CreateNoWindow = true;
            cmd.StartInfo.UseShellExecute = false; //to read           

            cmd.StartInfo.Verb = "runas"; //netstat -b requires elvated privlidges
            //manifest file needs to be created as well. Instructions found here: Change level="highestAvailable". Highest privledge for User.
            //https://stackoverflow.com/questions/6050478/how-do-i-create-edit-a-manifest-file

            //starts command prompt
            cmd.Start();          
            cmd.StandardInput.WriteLine(command2Run);//What we put into command prompt.
            cmd.StandardInput.Flush();
            cmd.StandardInput.Close();

            string output = cmd.StandardOutput.ReadToEnd(); //returns command prompt as a string

            richTextBox1.Text = output;
            label1.Text = "Done";
            label1.Refresh();
        }//end function

        private void Save_Metrics_Click(object sender, EventArgs e)
        {
            SaveFile();      
        }

        public void SaveFile()
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "Text file (*.txt)|*.txt|All files (*.*)|*.*";
            saveFileDialog.Title = "Save NetStat";

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                using (StreamWriter writer = new StreamWriter(saveFileDialog.OpenFile()))
                {
                    writer.WriteLine(richTextBox1.Text);
                }
            }//end if
        }//end function

        
        private void button2_Click(object sender, EventArgs e)//Loads Text File
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                string filePath = openFileDialog1.FileName;
                using (StreamReader reader = new StreamReader(filePath))
                {
                    richTextBox2.Text = reader.ReadToEnd();
                }
            }//end if
        }//end function

        private void compare_button_Click(object sender, EventArgs e)
        {
            int length = richTextBox1.Text.Length;
            int Rb2Length = richTextBox1.Text.Length;
            int appendNumber = 0;

            if (length > Rb2Length) { 
                appendNumber = length - Rb2Length;
                for (int i = 0; i < appendNumber; i++)
                    richTextBox2.AppendText("0");
             }//end if

            if (length < Rb2Length)
            {
                appendNumber = Rb2Length -length ;
                for (int i = 0; i < appendNumber; i++)                
                    richTextBox2.AppendText("0");
                
            }//end if

            if(length != Rb2Length)
            {
                MessageBox.Show("length does not match");
                return;
            }
                

            try
            {   //compares the two boxes
                for (int i = 0; i < length; i++)
                {
                    if (richTextBox1.Text[i] != richTextBox2.Text[i])
                    {
                        richTextBox1.Select(i, 1);
                        richTextBox1.SelectionColor = Color.Red;  //change character to red                      
                    }
                }//end For
            }
            catch (Exception ex) {
                MessageBox.Show("Something went wrong: " + ex);
            }//end try
        }//end function
       
    }//end class
}

